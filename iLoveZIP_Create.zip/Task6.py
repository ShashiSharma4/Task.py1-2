import csv
import os
class Student:
    def __init__(self, roll, name, marks):
        self.roll = roll
        self.name = name
        self.marks = marks

    def to_list(self):
        return [self.roll, self.name, self.marks]

# File handling class
FILE_NAME = "students.csv"

def initialize_file():
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Roll", "Name", "Marks"])  # header


def add_student(student):
    with open(FILE_NAME, mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(student.to_list())
    print("Student record added successfully!")


def display_students():
    try:
        with open(FILE_NAME, mode="r") as file:
            reader = csv.reader(file)
            for row in reader:
                print(row)
    except FileNotFoundError:
        print("⚠ File not found. Please add a student first.")


def search_student(roll_no):
    try:
        with open(FILE_NAME, mode="r") as file:
            reader = csv.reader(file)
            for row in reader:
                if row[0] == roll_no:
                    print("Student found:", row)
                    return
        print(" Student not found.")
    except FileNotFoundError:
        print("⚠ File not found.")
# Menu program
def main():
    initialize_file()

    while True:
        print("\n--- Student Management System ---")
        print("1. Add Student")
        print("2. Display Students")
        print("3. Search Student by Roll No")
        print("4. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            roll = input("Enter Roll No: ")
            name = input("Enter Name: ")
            try:
                marks = float(input("Enter Marks: "))
                student = Student(roll, name, marks)
                add_student(student)
            except ValueError:
                print("Invalid marks! Please enter a number.")

        elif choice == "2":
            display_students()

        elif choice == "3":
            roll_no = input("Enter Roll No to search: ")
            search_student(roll_no)

        elif choice == "4":
            print("Exiting program...")
            break

        else:
            print("⚠ Invalid choice. Please try again.")


if __name__ == "__main__":
    main()
